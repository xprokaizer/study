-- phpMyAdmin SQL Dump
-- version 5.2.0
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 02 Jan 2023 pada 05.42
-- Versi server: 10.4.24-MariaDB
-- Versi PHP: 7.4.29

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_inventarisk`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `barang`
--

CREATE TABLE `barang` (
  `id_barang` int(11) NOT NULL,
  `id_type_barang` varchar(2) NOT NULL,
  `merek_barang` varchar(50) NOT NULL,
  `Spesifikasi` varchar(255) NOT NULL,
  `Sumber` varchar(255) NOT NULL,
  `Lokasi_barang` varchar(2) NOT NULL,
  `Kondisi_barang` varchar(15) NOT NULL,
  `tanggal_input` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `barang`
--

INSERT INTO `barang` (`id_barang`, `id_type_barang`, `merek_barang`, `Spesifikasi`, `Sumber`, `Lokasi_barang`, `Kondisi_barang`, `tanggal_input`) VALUES
(1, '1', 'ACER 2022 ', 'RAM 10 GB DAN LAIN-LAIN', 'HIBAH MASYARAKAT', '1', '1', '2023-01-01'),
(2, '1', 'ASUS 2023', 'RAM 12 GB', 'BANTUAN PEMDA', '1', '1', '2023-01-01'),
(3, '1', 'ASUS 2023', 'RAM 12 GB', 'BANTUAN PEMDA', '1', '1', '2023-01-01'),
(4, '1', 'ASUS 2023', 'RAM 12 GB', 'BANTUAN PEMDA', '2', '1', '2023-01-01'),
(5, '1', 'ACER 2023', 'RAM 23 GB', 'BANTUAN PEMDA', '3', '1', '2023-01-01'),
(6, '2', 'te', 'ete', 'eee', '1', '1', '2023-01-01'),
(7, '3', 'dad', 'dad', 'da', '3', '3', '2023-01-01'),
(8, '4', 'SIMBADA', 'LAIN-LAIN', 'BANTUAN', '1', '1', '2023-01-01'),
(9, '4', 'SIMBADA', 'BAGUS', 'BANTUAN', '1', '1', '2023-01-01'),
(10, '5', 'LCD', '-', 'BOS', '2', '1', '2023-01-02'),
(11, '5', 'LCD', '-', 'BOS', '2', '1', '2023-01-02'),
(12, '6', 'BENQ', '-', 'BOS', '2', '1', '2023-01-02');

-- --------------------------------------------------------

--
-- Struktur dari tabel `kondisi_barang`
--

CREATE TABLE `kondisi_barang` (
  `id_kondisi` int(11) NOT NULL,
  `Kondisi` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `kondisi_barang`
--

INSERT INTO `kondisi_barang` (`id_kondisi`, `Kondisi`) VALUES
(1, 'BAIK'),
(2, 'RUSAK'),
(3, 'HILANG');

-- --------------------------------------------------------

--
-- Struktur dari tabel `lokasi_barang`
--

CREATE TABLE `lokasi_barang` (
  `id_lokasi` int(11) NOT NULL,
  `Lokasi` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `lokasi_barang`
--

INSERT INTO `lokasi_barang` (`id_lokasi`, `Lokasi`) VALUES
(1, 'LAB KOMPUTER 1'),
(2, 'LAB KOMPUTER 2'),
(3, 'LAB KOMPUTER 3');

-- --------------------------------------------------------

--
-- Struktur dari tabel `roles`
--

CREATE TABLE `roles` (
  `role_id` int(11) NOT NULL,
  `role_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `roles`
--

INSERT INTO `roles` (`role_id`, `role_name`) VALUES
(1, 'Administrator'),
(2, 'User');

-- --------------------------------------------------------

--
-- Struktur dari tabel `role_permissions`
--

CREATE TABLE `role_permissions` (
  `permission_id` int(11) NOT NULL,
  `role_id` int(11) NOT NULL,
  `page_name` varchar(255) NOT NULL,
  `action_name` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `role_permissions`
--

INSERT INTO `role_permissions` (`permission_id`, `role_id`, `page_name`, `action_name`) VALUES
(1, 1, 'barang', 'list'),
(2, 1, 'barang', 'view'),
(3, 1, 'barang', 'add'),
(4, 1, 'barang', 'edit'),
(5, 1, 'barang', 'editfield'),
(6, 1, 'barang', 'delete'),
(7, 1, 'barang', 'import_data'),
(8, 1, 'kondisi_barang', 'list'),
(9, 1, 'kondisi_barang', 'view'),
(10, 1, 'kondisi_barang', 'add'),
(11, 1, 'kondisi_barang', 'edit'),
(12, 1, 'kondisi_barang', 'editfield'),
(13, 1, 'kondisi_barang', 'delete'),
(14, 1, 'kondisi_barang', 'import_data'),
(15, 1, 'lokasi_barang', 'list'),
(16, 1, 'lokasi_barang', 'view'),
(17, 1, 'lokasi_barang', 'add'),
(18, 1, 'lokasi_barang', 'edit'),
(19, 1, 'lokasi_barang', 'editfield'),
(20, 1, 'lokasi_barang', 'delete'),
(21, 1, 'lokasi_barang', 'import_data'),
(22, 1, 'type_barang', 'list'),
(23, 1, 'type_barang', 'view'),
(24, 1, 'type_barang', 'add'),
(25, 1, 'type_barang', 'edit'),
(26, 1, 'type_barang', 'editfield'),
(27, 1, 'type_barang', 'delete'),
(28, 1, 'type_barang', 'import_data'),
(29, 1, 'user', 'list'),
(30, 1, 'user', 'view'),
(31, 1, 'user', 'add'),
(32, 1, 'user', 'edit'),
(33, 1, 'user', 'editfield'),
(34, 1, 'user', 'delete'),
(35, 1, 'user', 'import_data'),
(36, 1, 'user', 'accountedit'),
(37, 1, 'user', 'accountview'),
(38, 1, 'role_permissions', 'list'),
(39, 1, 'role_permissions', 'view'),
(40, 1, 'role_permissions', 'add'),
(41, 1, 'role_permissions', 'edit'),
(42, 1, 'role_permissions', 'editfield'),
(43, 1, 'role_permissions', 'delete'),
(44, 1, 'roles', 'list'),
(45, 1, 'roles', 'view'),
(46, 1, 'roles', 'add'),
(47, 1, 'roles', 'edit'),
(48, 1, 'roles', 'editfield'),
(49, 1, 'roles', 'delete'),
(50, 2, 'barang', 'list'),
(51, 2, 'barang', 'view'),
(52, 2, 'barang', 'add'),
(53, 2, 'barang', 'edit'),
(54, 2, 'barang', 'editfield'),
(55, 2, 'type_barang', 'list'),
(56, 2, 'type_barang', 'view'),
(57, 2, 'type_barang', 'add'),
(58, 2, 'type_barang', 'edit'),
(59, 2, 'type_barang', 'editfield'),
(60, 2, 'user', 'accountedit'),
(61, 2, 'user', 'accountview');

-- --------------------------------------------------------

--
-- Struktur dari tabel `type_barang`
--

CREATE TABLE `type_barang` (
  `id_type_barang` int(11) NOT NULL,
  `nama_barang` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `type_barang`
--

INSERT INTO `type_barang` (`id_type_barang`, `nama_barang`) VALUES
(1, 'LAPTOP'),
(2, 'KEYBOARD'),
(3, 'MOUSE'),
(4, 'SPEAKER'),
(5, 'MONITOR'),
(6, 'PROJEKTOR');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `id_user` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) DEFAULT NULL,
  `nama` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `photo` varchar(255) NOT NULL,
  `login_session_key` varchar(255) DEFAULT NULL,
  `email_status` varchar(255) DEFAULT NULL,
  `password_expire_date` datetime DEFAULT '2023-04-01 00:00:00',
  `password_reset_key` varchar(255) DEFAULT NULL,
  `user_role_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`id_user`, `username`, `password`, `nama`, `email`, `photo`, `login_session_key`, `email_status`, `password_expire_date`, `password_reset_key`, `user_role_id`) VALUES
(1, 'admin', '$2y$10$vJPpMK00h7.mPXMb3ZKFh.nrn7/Nh/1F8yZ/u26.LkPnRVKken0qG', 'admin', 'admin@gmail.com', 'http://localhost/aplikasiinvetarisk/uploads/files/vsy0mi4qd137efc.jpg', NULL, NULL, '2023-04-01 00:00:00', NULL, 1),
(2, 'user', '$2y$10$jfL6c8Cucgn8BB/vfBI8eec0fAqOxXttzqNC42VOOVtYE.aehbwxe', 'user', 'user@gmail.com', 'http://localhost/aplikasiinvetarisk/uploads/files/184p629lbnv3xfa.jpg', NULL, NULL, '2023-04-01 00:00:00', NULL, 2);

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `barang`
--
ALTER TABLE `barang`
  ADD PRIMARY KEY (`id_barang`);

--
-- Indeks untuk tabel `kondisi_barang`
--
ALTER TABLE `kondisi_barang`
  ADD PRIMARY KEY (`id_kondisi`);

--
-- Indeks untuk tabel `lokasi_barang`
--
ALTER TABLE `lokasi_barang`
  ADD PRIMARY KEY (`id_lokasi`);

--
-- Indeks untuk tabel `roles`
--
ALTER TABLE `roles`
  ADD PRIMARY KEY (`role_id`),
  ADD UNIQUE KEY `role_name` (`role_name`);

--
-- Indeks untuk tabel `role_permissions`
--
ALTER TABLE `role_permissions`
  ADD PRIMARY KEY (`permission_id`);

--
-- Indeks untuk tabel `type_barang`
--
ALTER TABLE `type_barang`
  ADD PRIMARY KEY (`id_type_barang`);

--
-- Indeks untuk tabel `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id_user`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `barang`
--
ALTER TABLE `barang`
  MODIFY `id_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `kondisi_barang`
--
ALTER TABLE `kondisi_barang`
  MODIFY `id_kondisi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `lokasi_barang`
--
ALTER TABLE `lokasi_barang`
  MODIFY `id_lokasi` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;

--
-- AUTO_INCREMENT untuk tabel `roles`
--
ALTER TABLE `roles`
  MODIFY `role_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `role_permissions`
--
ALTER TABLE `role_permissions`
  MODIFY `permission_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=62;

--
-- AUTO_INCREMENT untuk tabel `type_barang`
--
ALTER TABLE `type_barang`
  MODIFY `id_type_barang` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT untuk tabel `user`
--
ALTER TABLE `user`
  MODIFY `id_user` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
