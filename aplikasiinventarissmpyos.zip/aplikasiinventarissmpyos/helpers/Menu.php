<?php
/**
 * Menu Items
 * All Project Menu
 * @category  Menu List
 */

class Menu{
	
	
			public static $navbarsideleft = array(
		array(
			'path' => 'home', 
			'label' => 'Home', 
			'icon' => '<i class="fa fa-home "></i>'
		),
		
		array(
			'path' => 'user', 
			'label' => 'User', 
			'icon' => '<i class="fa fa-user "></i>'
		),
		
		array(
			'path' => 'barang', 
			'label' => 'Barang', 
			'icon' => '<i class="fa fa-file "></i>'
		),
		
		array(
			'path' => 'type_barang', 
			'label' => 'Type Barang', 
			'icon' => '<i class="fa fa-file-archive-o "></i>'
		),
		
		array(
			'path' => 'kondisi_barang', 
			'label' => 'Kondisi Barang', 
			'icon' => '<i class="fa fa-file-archive-o "></i>'
		),
		
		array(
			'path' => 'lokasi_barang', 
			'label' => 'Lokasi Barang', 
			'icon' => '<i class="fa fa-map "></i>'
		),
		
		array(
			'path' => 'role_permissions', 
			'label' => 'Role Permissions', 
			'icon' => ''
		),
		
		array(
			'path' => 'roles', 
			'label' => 'Roles', 
			'icon' => ''
		)
	);
		
	
	
}